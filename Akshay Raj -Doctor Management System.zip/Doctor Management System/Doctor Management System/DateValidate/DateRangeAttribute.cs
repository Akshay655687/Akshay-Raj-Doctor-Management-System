﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Doctor_Management_System.DateValidate
{
    public class DateRangeAttribute: ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {

            if (value != null)
            {
                DateTime dt = Convert.ToDateTime(value);

                if (dt <= DateTime.Now.AddDays(60) && dt >= DateTime.Now)
                {
                    return ValidationResult.Success;
                }
            }
            return new ValidationResult("Date should be between current date and two upcoming months from now.");
        }
    }
}
