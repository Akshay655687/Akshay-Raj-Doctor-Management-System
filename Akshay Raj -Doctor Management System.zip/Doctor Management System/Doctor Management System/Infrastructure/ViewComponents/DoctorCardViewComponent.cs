﻿using Doctor_Management_System.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Doctor_Management_System.Infrastructure.ViewComponents
{
    public class DoctorCardViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke(Doctor doctor)
        {
            return View(doctor);
        }
    }
}
