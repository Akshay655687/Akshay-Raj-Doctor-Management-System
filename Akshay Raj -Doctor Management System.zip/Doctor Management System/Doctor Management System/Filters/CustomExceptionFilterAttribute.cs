﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Doctor_Management_System.Filters
{
    public class CustomExceptionFilterAttribute : ExceptionFilterAttribute, IExceptionFilter
    {
        private HttpContextAccessor httpContextAccessor;
        public CustomExceptionFilterAttribute(HttpContextAccessor httpContextAccessor)
        {
            this.httpContextAccessor = httpContextAccessor;
        }
        public override void OnException(ExceptionContext context)
        {
            httpContextAccessor.HttpContext.Response.WriteAsync("Internal server error, please contact admin.");

        }
    }
}
