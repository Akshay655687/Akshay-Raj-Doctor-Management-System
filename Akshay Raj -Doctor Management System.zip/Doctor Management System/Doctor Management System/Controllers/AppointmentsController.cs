﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Doctor_Management_System.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Doctor_Management_System.Controllers
{
    public class AppointmentsController : Controller
    {
        private DoctorManagementSystemDbContext doctorManagementDb;
        public AppointmentsController(DoctorManagementSystemDbContext doctorManagementDb)
        {
            this.doctorManagementDb = doctorManagementDb;
        }
        // GET: /<controller>/
        public IActionResult Book()
        {
            return View();
        }

        //public async Task<IActionResult> AppointmentDetails()
        //{
        //    return View(await doctorManagementDb.Appointments.ToListAsync());
        //}

        [HttpGet]
        public async Task<IActionResult> BookAppointment()
        {
            DoctorAppointmentViewModel doctorAppointmentViewModel = new DoctorAppointmentViewModel();
            doctorAppointmentViewModel.Doctors = await doctorManagementDb.Doctors.ToListAsync();
            doctorAppointmentViewModel.Appointment = new Appointment();

            return View(doctorAppointmentViewModel);
            //return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BookAppointment(Appointment appointment)
        {
            //  await doctorManagementDb.Appointments.AddAsync(appointment);
            //  await  doctorManagementDb.SaveChangesAsync();

            //  ViewBag.Message = "Appointment Booked Successfully";

            //// return RedirectToAction("BookAppointment","Appointments");

            // return View("Book");

            var appointmentBooked = doctorManagementDb.Appointments.Where(a => a.AppointmentDate == appointment.AppointmentDate && a.AppointmentTime == appointment.AppointmentTime && a.DoctorId == appointment.DoctorId).FirstOrDefault();
            if (appointmentBooked != null)
            {
                ModelState.AddModelError(nameof(appointment.AppointmentTime), "Sorry this slot already booked, please select another slot");
            }

            if (ModelState.IsValid)
            {
                await doctorManagementDb.Appointments.AddAsync(appointment);
                await doctorManagementDb.SaveChangesAsync();
                ViewBag.Message = "Appointment Scheduled! Please be there on time";
            }
            else
            {
                if (appointmentBooked != null)
                    TempData["msg"] = "Sorry this slot already booked, please select another slot";
                else
                    TempData["msg"] = "Appointment Date can not be more than sixty days from today";
                return RedirectToAction("BookAppointment");
            }
            //return View("AppointmentDetails", await doctorManagementDb.Appointments.ToListAsync());
            return View("Book");
        }
    }
}
