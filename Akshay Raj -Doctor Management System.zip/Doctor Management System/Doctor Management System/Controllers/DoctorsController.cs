﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Doctor_Management_System.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
//using System.IO;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Doctor_Management_System.Controllers
{
    public class DoctorsController : Controller
    {
        private DoctorManagementSystemDbContext doctorManagementDb;
        public DoctorsController(DoctorManagementSystemDbContext doctorManagementDb)
        {
            this.doctorManagementDb = doctorManagementDb;
        }
        public async Task<IActionResult> Index(int id)
        {
           
            return View(await doctorManagementDb.Doctors.ToListAsync());
        }


        [HttpGet]
        public async Task<IActionResult> Create()
        {
            DoctorCityViewModel doctorCityViewModel = new DoctorCityViewModel();
            doctorCityViewModel.Cities = await doctorManagementDb.Cities.ToListAsync();
            doctorCityViewModel.Doctor = new Doctor();

            return View(doctorCityViewModel);
        }
      

        [HttpPost]
        public async Task<IActionResult> Create(Doctor doctor)
        {
            await doctorManagementDb.Doctors.AddAsync(doctor);
            await doctorManagementDb.SaveChangesAsync();
            //employees.Add(employee);
            //return View("Index",employees);
            return View("Index", await doctorManagementDb.Doctors.ToListAsync());
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            Doctor doctor = doctorManagementDb.Doctors.Include("City").Where(i => i.Id == id).FirstOrDefault();
            ViewBag.catList = new SelectList(doctorManagementDb.Cities, "Id", "Name");
            return View(doctor);

        }
        [HttpPost]
        public IActionResult Edit(Doctor doctor)
        {
          
            Doctor d = doctorManagementDb.Doctors.Include("City").Where(i => i.Id == doctor.Id).FirstOrDefault();
            d.Name = doctor.Name;
            d.Mobile = doctor.Mobile;
            d.DateOfBirth = doctor.DateOfBirth;
            d.Speciality = doctor.Speciality;
            d.Experience = doctor.Experience;
            d.VirtualConsultation = doctor.VirtualConsultation;
            d.City = doctorManagementDb.Cities.Where(i => i.Id == doctor.CityId).FirstOrDefault();
            doctorManagementDb.Doctors.Update(d);
            ViewBag.catList = new SelectList(doctorManagementDb.Cities, "Id", "Name");
            doctorManagementDb.SaveChanges();
            //Response.Write("<script>alert('Menu Item Updated Succesfully')</script>");
            return View("Index", doctorManagementDb.Doctors.ToList());
          
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
           
             var doctor = doctorManagementDb.Doctors.Where(e => e.Id == id).FirstOrDefault();
            doctor.City = doctorManagementDb.Cities.Where(c => c.Id == doctor.CityId).FirstOrDefault();

            return View(doctor);
        }
        [HttpPost]
        public IActionResult Delete( Doctor doctor)
        {
                Doctor d= doctorManagementDb.Doctors.Find(doctor.Id);
                doctorManagementDb.Doctors.Remove(d);
                doctorManagementDb.SaveChanges();
                //return RedirectToAction(nameof(Index), new { id = doctor.Id });
                return View("Index", doctorManagementDb.Doctors.ToList());
           
           
        }




        public IActionResult Details(int id)
        {
            var doctor = doctorManagementDb.Doctors.Where(e => e.Id == id).FirstOrDefault();
            doctor.City = doctorManagementDb.Cities.Where(c => c.Id == doctor.CityId).FirstOrDefault();

            return View(doctor);
           // return View("Details", doctorManagementDb.Doctors.ToList());
        }
    }
}
