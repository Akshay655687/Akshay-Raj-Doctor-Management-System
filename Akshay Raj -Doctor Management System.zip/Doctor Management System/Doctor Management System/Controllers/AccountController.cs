﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Doctor_Management_System.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Doctor_Management_System.Controllers
{
    public class AccountController : Controller
    {
        // GET: /<controller>/
        private DoctorManagementSystemDbContext doctorManagementSystemDbContext;
        public AccountController(DoctorManagementSystemDbContext doctorManagementSystemDbContext)
        {
            this.doctorManagementSystemDbContext = doctorManagementSystemDbContext;
        }

        [HttpGet]
        public IActionResult SignUp()
        {
            //ViewBag.Message1 = "Signup Page";
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> SignUp(ApplicationUser applicationUser)
        {
            //ViewBag.Message1 = "Signup Page";
            if (ModelState.IsValid)
            {
                doctorManagementSystemDbContext.Users.Add(applicationUser);
                await doctorManagementSystemDbContext.SaveChangesAsync();
                ViewBag.Message = "Signup successfully..Thanks for registering with us! Go to <a href='login'>Login</a>";
                return View();
            }
            else
            {
                ViewBag.Message = "Signup Failed,Try again ..!!";
                return View(applicationUser);
            }


        }

        [HttpGet]
        public IActionResult Login()
        {
            //ViewBag.Message2 = "Login Page";
            return View();
        }

        [HttpPost]
        public IActionResult Login(ApplicationUser applicationUser)
        {
            //ViewBag.Message2 = "Login Page";
            var user = doctorManagementSystemDbContext
                .Users.Where(u => u.Email == applicationUser.Email && u.Password == applicationUser.Password)
                .FirstOrDefault();
            if (user == null)
            {
                ViewBag.Message = "Invalid username/password!";
                return View();
            }

            HttpContext.Session.SetString("FullName", user.FullName);
            ViewBag.Message = "Login successful!";
            return RedirectToAction("Index", "Doctors");
            //if (user != null)
            //    ViewBag.Message = "Login successful!";
            //else
            //    ViewBag.Message = "Invalid username/password!";
            //return View();
        }

        [HttpGet]
        public IActionResult Logout()
        {
            //ViewBag.Message2 = "Login Page";
            HttpContext.Session.Remove("FullName");
            return View("Login");
        }
    }
}
