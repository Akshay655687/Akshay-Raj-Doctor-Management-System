﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Doctor_Management_System.Models
{
    public class Doctor
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide Doctor name")]
        [StringLength(maximumLength: 255)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please provide Mobile no.")]
        public string Mobile { get; set; }

        [Required(ErrorMessage ="Please Provide Date Of Birth")]
        [DataType(DataType.Date)] 
        [DisplayFormat(DataFormatString = "{0:dd-MM-yy}", ApplyFormatInEditMode = false)]
        public DateTime DateOfBirth { get; set; }
        [Required(ErrorMessage = "Please Provide speciality")]
        public String Speciality { get; set; }

        [Required(ErrorMessage = "Please provide experience")]
        [Range(minimum:0,maximum:50)]
        public int Experience { get; set; }

        [Required(ErrorMessage = "Please provide Consultation")]
        [Display(Name ="Virtual Consultation supported?")]

        public bool VirtualConsultation { get; set; }

        [Required(ErrorMessage = "Please provide City")]
        [Display(Name = "City")]
        public int CityId { get; set; }

        public City City { get; set; }

        public virtual List<Appointment> Appointments { get; set; }
    }
}
