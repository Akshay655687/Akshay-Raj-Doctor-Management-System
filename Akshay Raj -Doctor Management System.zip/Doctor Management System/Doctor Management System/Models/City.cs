﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Doctor_Management_System.Models
{
    public class City
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide City name")]
        [StringLength(maximumLength:50)]
        public string Name { get; set; }

        public virtual List<Doctor> Doctors { get; set; }
    }
}
