﻿using Doctor_Management_System.DateValidate;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Doctor_Management_System.Models
{
    public class Appointment
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide Patient name")]
        [StringLength(maximumLength:50)]
        public string PatientName { get; set; }

        [Required(ErrorMessage = "Please provide Patient Mobile")]
        [MaxLength(10)]
        public string PatientMobile { get; set; }

        [Required(ErrorMessage = "Please provide Patient Gender")]
        
        public string PatientGender { get; set; }

        [Required(ErrorMessage = "Please provide Patient Age")]
        [Range(minimum: 0, maximum: 100)]

        public int PatientAge { get; set; }

        [Required(ErrorMessage = "Please Provide valid Appointment Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yy}", ApplyFormatInEditMode = false)]
        [DateRange]
        public DateTime AppointmentDate { get; set; }

        [Required(ErrorMessage = "Please Provide valid Appointment Time")]
        public string AppointmentTime { get; set; }


        [Required(ErrorMessage = "Please provide Doctor")]
        
        public int DoctorId { get; set; }

        public Doctor Doctor { get; set; }

    }
}
