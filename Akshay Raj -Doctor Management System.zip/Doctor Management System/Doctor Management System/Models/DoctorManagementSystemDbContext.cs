﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Doctor_Management_System.Models
{
    public class DoctorManagementSystemDbContext: DbContext
    {
        public DoctorManagementSystemDbContext(DbContextOptions<DoctorManagementSystemDbContext> options) : base(options)
        {

        }

        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<City> Cities { get; set; }

        public DbSet<ApplicationUser> Users { get; set; }

        public DbSet<Appointment> Appointments { get; set; }
    }
}
