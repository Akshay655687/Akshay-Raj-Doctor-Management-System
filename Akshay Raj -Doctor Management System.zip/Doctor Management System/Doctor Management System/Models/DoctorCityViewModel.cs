﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Doctor_Management_System.Models
{
    public class DoctorCityViewModel
    {
        public List<City> Cities { get; set; }
        public Doctor Doctor { get; set; }
    }
}
