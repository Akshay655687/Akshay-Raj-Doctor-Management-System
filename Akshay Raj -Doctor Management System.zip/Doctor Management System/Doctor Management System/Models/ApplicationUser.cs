﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Doctor_Management_System.Models
{
    public class ApplicationUser
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Please provide a valid email")]
        [DataType(DataType.EmailAddress)]

        public string Email { get; set; }

        [Required(ErrorMessage = "Please provide Full Name")]
        [MaxLength(100)]
        public string FullName { get; set; }

        [Required(ErrorMessage = "Please provide password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
